package com.bankapplication.service;


import java.util.Random;
import java.util.Scanner;

import com.bankapplication.model.Account;

public class BankServiceImplements implements BankService {

	Account ac=new Account();
	Scanner sc=new Scanner(System.in);
	
	public void createBankAccount(){
		System.out.println("enter your name");
		String name=sc.next();
		ac.setUser_name(name);
		System.out.println("enter your address");
		String address=sc.next();
		ac.setUser_address(address);
		System.out.println("enter your PAN");
		String pan_no=sc.next();
		ac.setpan_no(pan_no);
		System.out.println("enter the amount deposit");
		int deposit=sc.nextInt();
		ac.setBalance(deposit);
		//generating random number using random
		Random random=new Random();
		long accno=random.nextLong(100000000000l);
	//ac.setAcc_no(accno);
		System.out.println("your account number created successfully and your account number is "+accno);
		
	}

    @Override	
	public void viewAccountDetails() {
       System.out.println("enter your account number");
       int userAccountNumber=sc.nextInt();
       if(ac.getAcc_no()==userAccountNumber);{
		System.out.println("fetching the account details");
		System.out.println(ac.getAcc_no());
		System.out.println(ac.getUser_name());
		System.out.println(ac.getUser_address());
		System.out.println(ac.getpan_no());
		System.out.println(ac.getBalance());
		
		ac.toString();
		}
//       else{
//    	   System.out.println("create account first");
//       }
		
	}

    @Override	
	public void withdrawMoney() {
		System.out.println("enter your account number");
		int accno=sc.nextInt();
		if (ac.getAcc_no()==accno){
			System.out.println("enter the amount to withdraw");
			int debitAmount=sc.nextInt();
			int balance=ac.getAcc_no();
			if(debitAmount<balance){
				balance=balance-debitAmount;
				System.out.println("amount withdraw successfully and the available balance is:"+balance);
				}
			else {
				System.out.println("insufficient fund");
			}
		}
			else{
				System.out.println("create your account first");
				}			
			}
    @Override			
	public void depositeMoney() {
		System.out.println("enter your account number");
		Scanner sc=new Scanner(System.in);
		int accno=sc.nextInt();
		if(ac.getAcc_no()==accno);{
		System.out.println("enter theamount which you wants deposit");
		int creditAmount=sc.nextInt();
		int balance=ac.getBalance()+creditAmount;
		ac.setBalance(balance);
		System.out.println("amount deposit succesfully and the available balance is:"+balance);
		}
//		else{
//			System.out.println("create your account first");
//		}
//		
    }
 		
	 @Override	
	public void updateAccountDetails() {
		System.out.println("enter your account number");
		int accno=sc.nextInt();
		if(ac.getAcc_no()==accno);
		{
			boolean flag =true;
			while(flag);
		}
		
		System.out.println("press 1 for name update");
		System.out.println("press 2 for address update");
		System.out.println("press 1 for pan update");
		System.out.println("press 1 for exit");
		int ch=sc.nextInt();
		switch(ch){
		case 1:
			System.out.println("enter the name which you want to update");
			String user_name=sc.next();
			ac.setUser_name(user_name);
			System.out.println("name updated successfully and the updated details are"+ac.getUser_name());
			break;
		case 2:
			System.out.println("enter the address which you want to update");
			String user_address=sc.next();
			ac.getUser_address();
			System.out.println("address updated successfully and the updated details are"+ac.getUser_address());
			break;
		case 3:
			System.out.println("enter the pan no which you want to update");
			String user_pan=sc.next();
			ac.setpan_no(user_pan);
			System.out.println("pan no updated successfully and the updated details are"+ac.getpan_no());
			break;
		case 4:
			boolean flag = false;
			break;
			
		default:
			System.out.println("create your account first");
			break;
		}
	 }}
//	


	